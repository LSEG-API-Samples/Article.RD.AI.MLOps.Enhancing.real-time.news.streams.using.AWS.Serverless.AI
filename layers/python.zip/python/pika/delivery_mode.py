from enum import Enum


class DeliveryMode(Enum):
    Transient = 1
    Persistent = 2
